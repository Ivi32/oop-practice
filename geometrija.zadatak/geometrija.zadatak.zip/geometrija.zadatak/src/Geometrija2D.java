public abstract class Geometrija2D extends Geometrija{
    public Geometrija2D (String ime) {
        super(ime);
    }


    public abstract double obim();
}
