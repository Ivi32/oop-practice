public class GeometrijaTest2 {
    public static void main(String[] args) {
        //Zelim da preko metoda dohvatam obim i povrsinu

    /*public double povrsina(Krug k) {
        return k.povrsina();
    }

    public double povrsina(Elipsa e) {
        return e.povrsina();
    }

    public double povrsina(Kvadrat k) {
        return k.povrsina();
    }

    public double povrsina(Pravougaonik p) {
        return p.povrsina();
    }*/





    }
}