public class test {
    public static void main(String[] args) {
        Elipsa elipsa = new Elipsa(6,9);
        System.out.println(elipsa);
        System.out.println("=========");
        Krug krug = new Krug(5);
        System.out.println(krug);
    }
}
