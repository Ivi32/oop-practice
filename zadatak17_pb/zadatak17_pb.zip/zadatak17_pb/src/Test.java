public class Test {
    public static void main(String[] args) {

        Krava krava = new Krava(500, 4, "Belka");
        System.out.println(krava.daLiSeJedem());
        krava.oglasiSe();

    }
}
