public abstract class Figura extends Oblik{
    //Napisati abstrakntu klasu Figura koja nasledjuje klasu Oblik i nema atribute
    //
    //Figura je 2D geometrijsko telo
    //
    //Napisati prazan konstruktor
    //
    //Overridovati metod:
    //zapremina() - vratiti 0


    public Figura() {
    }

    @Override
    public double zapremina() {
        return 0;
    }
}
