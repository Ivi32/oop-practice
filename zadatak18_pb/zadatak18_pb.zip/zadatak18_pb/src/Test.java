public class Test {
    public static void main(String[] args) {
        Kocka kocka = new Kocka(2);
        System.out.println(kocka.getIme());

        Prizma prizma = new Prizma(5, 10);
        System.out.println(prizma.zapremina());
    }
}