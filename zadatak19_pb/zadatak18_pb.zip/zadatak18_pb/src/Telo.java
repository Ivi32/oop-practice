public abstract class Telo extends Oblik{
    //Napisati abstraktnu klasu Telo koja nasledjuje klasu Oblik i nema atribute
    //
    //Napisati prazan konstruktor


    public Telo() {
    }
}
