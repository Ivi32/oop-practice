public interface Pokretljivo {
    //Napisati interfejs Pokretljivo koja definise metode
    //1.void pokreniSe() - koja ispisuje kako se nesto krece
    //2.String potrosnja() - koja vraca koju vrstu goriva koristi pokretljiva s

    void pokreniSe();
    String potrosnja();
}
